const config = {
    // apiUrl: "https://api.mockperiod.com",
    // apiUrl: "https://cod.crpch.in",
    apiUrl: 'http://localhost:8080/api',
};

export default config;
