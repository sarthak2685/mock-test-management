const config = {
    apiUrl: "https://new.dbmcrj.ac.in",
    //apiUrl: "https://cod.crpch.in",
    // apiUrl: 'https://mockexam.pythonanywhere.com',
};

export default config;
